from pympler.tracker import SummaryTracker
tracker = SummaryTracker()
RFID_Controller()

tracker.print_diff
