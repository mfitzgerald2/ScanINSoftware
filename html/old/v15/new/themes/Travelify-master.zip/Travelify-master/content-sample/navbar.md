---
title: Navigation bar
---

 - [Home](%base_url%)
 - [Category 1](#)
	- [Page 1.1](%base_url%?a/a)
	    - [Page 1.1.1](%base_url%?a/a/a)
	- [Page 1.2](%base_url%?a/b)
 - [Category 2](#)
	- [Page 2.1](#)
	- [Page 2.2](#)
 
