---
title: Links
---

 * [University of Helsinki](https://www.helsinki.fi/en)
 * [Department of Computer Science](https://www.cs.helsinki.fi/en)
 * [Helsinki Doctoral Education Network in Information and Communications Technology (HICT)](http://www.hict.fi/)